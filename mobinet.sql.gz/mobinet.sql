-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Сен 28 2020 г., 17:30
-- Версия сервера: 10.4.11-MariaDB
-- Версия PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `mobinet`
--

-- --------------------------------------------------------

--
-- Структура таблицы `basket`
--

CREATE TABLE `basket` (
  `id_basket` int(11) NOT NULL,
  `id_order` int(11) DEFAULT NULL,
  `id_user` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `basket`
--

INSERT INTO `basket` (`id_basket`, `id_order`, `id_user`, `id_good`, `amount`) VALUES
(325, 167, 153, 34, 1),
(326, 167, 153, 35, 2),
(327, 168, 153, 42, 1),
(328, 168, 153, 43, 3),
(329, 169, 154, 49, 1),
(330, 169, 154, 50, 1),
(331, 169, 154, 73, 1),
(332, 169, 154, 25, 1),
(333, 170, 154, 35, 1),
(334, 170, 154, 48, 1),
(335, 170, 154, 51, 1),
(336, 171, 154, 49, 1),
(341, 171, 154, 34, 1),
(342, 171, 154, 42, 1),
(343, 172, 160, 34, 1),
(344, 172, 160, 61, 1),
(345, 172, 160, 48, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `brands`
--

CREATE TABLE `brands` (
  `id_brand` int(11) NOT NULL,
  `name_brand` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `brands`
--

INSERT INTO `brands` (`id_brand`, `name_brand`) VALUES
(5, 'Alcatel'),
(17, 'Bliss'),
(4, 'Explay'),
(9, 'Fly'),
(15, 'Globus'),
(10, 'Highscreen'),
(1, 'Huawei'),
(12, 'LG'),
(18, 'Motorola'),
(14, 'MTC'),
(19, 'Nokia'),
(11, 'Philips'),
(8, 'Prestigio'),
(2, 'Samsung'),
(13, 'Sony'),
(16, 'TeXet'),
(52, 'Xiaomi'),
(3, 'ZTE'),
(21, 'Мегафон');

-- --------------------------------------------------------

--
-- Структура таблицы `discounts`
--

CREATE TABLE `discounts` (
  `id_discount` int(11) NOT NULL,
  `name_discount` varchar(512) NOT NULL,
  `percent` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `discounts`
--

INSERT INTO `discounts` (`id_discount`, `name_discount`, `percent`, `created_at`, `updated_at`) VALUES
(42, 'Золотая осень', '50', '2020-09-24 11:34:06', '2020-09-24 11:34:06'),
(43, 'Супер-акция 70', '70', '2020-09-24 12:08:36', '2020-09-24 12:08:36'),
(44, 'Супер-акция 75', '75', '2020-09-24 12:23:26', '2020-09-24 12:23:26'),
(46, 'Супер-акция 50', '50', '2020-09-28 06:11:44', '2020-09-28 06:11:48');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id_good` int(11) NOT NULL,
  `id_brand` int(11) NOT NULL,
  `name_good` varchar(256) NOT NULL,
  `price_good` int(11) NOT NULL,
  `new_price` int(11) DEFAULT NULL,
  `photo` varchar(256) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id_good`, `id_brand`, `name_good`, `price_good`, `new_price`, `photo`, `description`, `created_at`) VALUES
(25, 1, 'Huawei G500 Pro', 9000, 2700, 'Huawei G500 Pro.jpg', 'Смартфон  Huawei Ascend G500 Pro с установленной операционной системой Android 4.0  и размером дисплея 4.3 дюйма. . Есть возможность установить 2 sim карты.. Модель оснащена 4 Гб  памяти и процессор MediaTek MT6577, 1000 МГц .', '2020-03-09 06:13:44'),
(34, 1, 'Huawei Honor 2', 12000, 6000, 'Huawei Honor 2.jpg', 'В последнее время мечты все больше приближаются к реальности. Например, благодаря таким смартфонам, как Huawei Honor 2 \r\n – это актуальная и стильная модель с флагманской «начинкой» и мощной батареей. А благодаря отличной цене девайс доступен широкому кругу пользователей – тем, кто не готов переплачивать за именитый бренд, но хотел бы обзавестись смартфоном с широкими возможностями.', '2020-04-15 14:54:02'),
(35, 2, 'Samsung S5230', 8000, 4000, 'Samsung S5230.jpg', 'Телефон  Samsung La Fleur GT-S5230 с диагональю экрана 3 дюйма. . Телефон  иммет аккумулятор типа Li-Ion  позволяющий говорить до 4 часов  и находиться в режиме ожидания 250 часов . Модель поддерживает только одну сим-карту.. Так же, стоит отметить, что в Телефон  есть 50 Мб  памяти.', '2020-04-22 03:04:20'),
(36, 3, 'ZTE Grand ERA', 16000, 4800, 'ZTE Grand Era.jpg', 'Смартфон  ZTE Grand Era с операционной системой Android 4.0  и диагональю экрана 4.5 дюйма. . Смартфон  имеет аккумулятор Li-Ion . В данную модель нельзя установить больше одной sim-карты.. Модель оснащена 4 Гб  памяти и процессор NVIDIA Tegra 3, 1500 МГц', '2020-05-05 10:48:36'),
(42, 4, 'Explay Sky', 5000, 1500, 'explay_sky.jpg', 'Смартфон  Explay Sky с операционной системой Android 4.0  и размером дисплея 4 дюйма. . Смартфон  имеет аккумулятор Li-polymer  позволяющий говорить до 4.5 часов  и быть в режиме ожидания 320 часов . Модель Explay Sky имеет поддержку 2-ух sim-карт. Не лишним будет сказать, что Смартфон  имеет 4 Гб  памяти и процессор ARM Cortex-A9, 1000 МГц .', '2020-09-01 15:21:38'),
(43, 5, 'Alcatel OT-991', 6000, 1500, 'Alcatel-OT-991-401.jpg', 'Смартфон с 2012 года, весом 131.3 г и размером 122 x 68 x 10.8 мм. Он оснащен 4 дюймовым экраном 3.15 мегапиксельной камерой и памятью 150 MB. Его процессор 800 MHz Cortex-A9. Другие особенности\r\n- Датчики - Акселерометр, Датчик приближения, Компас \r\n- MP3/AAC+/WAV/WMA player\r\n-MP4/H.264 player\r\n-Document viewer\r\n-Photo viewer/editor\r\n-Organizer\r\n-Voice memo\r\n-Predictive text input', '2020-09-01 15:22:41'),
(45, 9, 'Fly IQ442 Miracle', 6000, 1500, 'fly_iq442_miracle.jpg', 'Смартфон  Fly IQ442 Miracle с операционной системой Android 4.0  и диагональю экрана 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion . Модель Fly IQ442 Miracle имеет поддержку 2-ух sim-карт. В Смартфон  установленно 4 Гб  памяти и процессор MediaTek MT6577, 1000 МГц .', '2020-09-01 15:23:31'),
(46, 10, 'Highscreen Yummy Duo', 3200, 800, 'Highscreen Yummy Duo.jpg', 'Смартфон  Highscreen Yummy Duo с операционной системой Android 2.3  и диагональю экрана 4.3 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion . Модель Highscreen Yummy Duo имеет поддержку 2-ух sim-карт. Для пользователя выделено 512 Мб  памяти и процессор MediaTek MT6573, 650 МГц .', '2020-09-01 15:23:48'),
(48, 4, 'Explay Advance', 6000, 3000, 'explay_advance.jpg', 'Смартфон  Explay Advance с установленной операционной системой Android 4.0  и размером дисплея 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion  дающий возможность общаться до 8 часов  и находиться в режиме ожидания 200 часов . Есть возможность установить 2 sim карты.. В Смартфон  установленно 4 Гб  памяти и процессор MediaTek MT6575, 1000 МГц .', '2020-09-01 15:25:19'),
(49, 5, 'Alcatel One Touch 928D', 5000, 1500, 'alcatel_one_touch_928d.jpg', 'Смартфон  Alcatel One Touch 928D с установленной операционной системой Android 2.3  и размером дисплея 4 дюйма. . Смартфон  имеет аккумулятор Li-Ion  позволяющий говорить до 12 часов  и быть в режиме ожидания 400 часов . Есть возможность установить 2 sim карты.. Для пользователя выделено 150 Мб  памяти и процессор 800 МГц .', '2020-09-01 15:25:36'),
(50, 3, 'ZTE V880E Dual', 6000, 0, 'ZTE V880E Dual.jpg', 'Смартфон  ZTE V880E Dual с операционной системой Android 2.3  и размером дисплея 4 дюйма. . Смартфон  оснащен аккумулятором типа Li-Ion  дающий возможность общаться до 5 часов  и находиться в режиме ожидания 380 часов . Стоит отметить, что у ZTE V880E Dual есть поддержка двух сим-карт. Модель оснащена 4 Гб  памяти и процессор Qualcomm MSM7227A, 1000 МГц', '2020-09-01 15:34:42'),
(51, 1, 'Huawei Ascend G300', 6200, 0, 'Huawei Ascend G300.jpg', 'Смартфон  Huawei Ascend G300, оснащенный операционной системой Android 2.3  и диагональю экрана 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion . В данную модель нельзя установить больше одной sim-карты.. Для пользователя выделено 4 Гб  памяти и процессор Qualcomm MSM7227A, 1000 МГц .', '2020-09-01 15:34:42'),
(52, 8, 'Prestigio MultiPhone 4300 DUO', 6400, 0, 'Prestigio MultiPhone 4300 DUO.jpg', 'Смартфон  Prestigio MultiPhone 4300 DUO с операционной системой Android 4.0  и диагональю экрана 4.3 дюйма. . Смартфон  иммет аккумулятор типа Li-polymer  позволяющий общаться до 3 часов  и находиться в режиме ожидания 120 часов . Есть возможность установить две сим карты.. Для пользователя выделено 4 Гб  памяти и процессор ARM Cortex-A9, 1000 МГц', '2020-09-01 15:34:42'),
(53, 3, 'ZTE V970', 6500, 0, 'ZTE V970.jpg', 'Смартфон  ZTE V970 с установленной операционной системой Android 4.0  и диагональю экрана 4.3 дюйма. . Смартфон  оснащен аккумулятором типа Li-Ion . В данную модель нельзя установить больше одной сим-карты.. Так же, стоит отметить, что в Смартфон  есть 4 Гб  памяти и процессор NVIDIA Tegra 2, 1000 МГц', '2020-09-01 15:34:42'),
(54, 3, 'ZTE V889M Dual', 6600, 0, 'ZTE V889M Dual.jpg', 'Смартфон  ZTE V889M Dual с операционной системой Android 4.0  и размером дисплея 4 дюйма. . Модель ZTE V889M Dual имеет поддержку 2-ух sim-карт. Для пользователя выделено 4 Гб  памяти и процессор MediaTek MT6577, 1000 МГц', '2020-09-01 15:34:43'),
(55, 11, 'Philips W536', 6800, 0, 'Philips W536.jpg', 'Смартфон  Philips W536, оснащенный операционной системой Android 4.0  и размером дисплея 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion  позволяющий общаться до 11 часов  и находиться в режиме ожидания 407 часов . Есть возможность установить две сим карты.. Смартфон  имеет 4 Гб  встроенной памяти на борту и процессор 1000 МГц', '2020-09-01 15:34:43'),
(56, 9, 'Fly IQ280', 6800, 0, 'fly_iq280.jpg', 'Смартфон  Fly IQ280 Tech с операционной системой Android 2.3  и диагональю экрана 4 дюйма. . Смартфон  имеет аккумулятор Li-Ion  дающий возможность общаться до 3 часов  и быть в режиме ожидания 120 часов . Модель поддерживает только одну сим-карту.. Для пользователя выделено 1 Гб  памяти и процессор Qualcomm MSM 8255T, 1200 МГц .', '2020-09-01 15:34:43'),
(57, 12, 'LG Optimus L5', 6900, 0, 'LG Optimus L5.jpg', 'Смартфон  LG Optimus L5 E612 с операционной системой Android 4.1  и размером дисплея 4 дюйма. . Модель поддерживает только одну сим-карту.. В Смартфон  установленно 2 Гб  памяти и процессор Qualcomm MSM7225A, 800 МГц .', '2020-09-01 15:34:43'),
(58, 12, 'LG Optimus Black P970', 7000, 0, 'LG Optimus Black P970.jpg', 'Смартфон  LG Optimus Black P970 с операционной системой Android 2.2  и размером дисплея 4 дюйма. . Смартфон  имеет аккумулятор Li-Ion . В данную модель нельзя установить больше одной sim-карты.. Для пользователя выделено 2 Гб  памяти и процессор TI OMAP3630, 1000 МГц .', '2020-09-01 15:34:43'),
(59, 5, 'Alcatel One Touch View', 7000, 0, 'alcatel_one_touch_view.jpg', 'Смартфон  Alcatel One Touch View с установленной операционной системой MS Windows Phone 7.5  и размером дисплея 4.08 дюйма. . В данную модель нельзя установить больше одной сим-карты.. В Смартфон  установленно 4 Гб  памяти и процессор Qualcomm MSM7227A, 1000 МГц .', '2020-09-01 15:34:43'),
(60, 5, 'Alcatel OT-993D', 7800, 0, 'alcatel_one_touch_993d.jpg', 'Перед приобретением Alcatel One Touch 993D по самой низкой цене, изучите характеристики, видео обзоры, плюсы и минусы модели, отзывы покупателей.', '2020-09-01 15:34:43'),
(61, 9, 'Fly IQ440 Energie', 7800, 0, 'fly_iq440_energie.jpg', 'Смартфон  Fly IQ440 Energie с установленной операционной системой Android 4.1  и диагональю экрана 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion  дающий возможность общаться до 7 часов  и быть в режиме ожидания 500 часов . Модель Fly IQ440 Energie имеет поддержку 2-ух sim-карт. Так же, стоит отметить, что в Смартфон  есть 4 Гб  памяти и процессор MediaTek MT6577, 1000 МГц .', '2020-09-01 15:34:43'),
(62, 12, 'LG Optimus L5 Dual', 7900, 0, 'LG Optimus L5 Dual.jpg', 'Смартфон  LG Optimus L5 Dual E615 с операционной системой Android 4.0  и диагональю экрана 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion  позволяющий говорить до 10 часов  и быть в режиме ожидания 600 часов . Есть возможность установить две сим карты.. Так же, стоит отметить, что в Смартфон  есть 4 Гб  памяти и процессор Qualcomm MSM7225A, 800 МГц', '2020-09-01 15:34:43'),
(64, 1, 'Huawei Ascend G302D', 7400, 0, 'Huawei Ascend G302D.jpg', 'Смартфон  Huawei Ascend G302D с установленной операционной системой Android 2.3  и размером дисплея 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion . Есть возможность установить две сим карты.. Так же, стоит отметить, что в Смартфон  есть 3.70 Гб  памяти и процессор MediaTek MT6575, 1000 МГц .', '2020-09-01 15:34:43'),
(65, 14, 'МТС 968', 7500, 0, 'МТС 968.jpg', 'Смартфон  МТС 968, оснащенный операционной системой Android 4.0  и размером дисплея 4 дюйма. . Смартфон  оснащен аккумулятором типа Li-Ion  дающий возможность общаться до 5.5 часов  и быть в режиме ожидания 325 часов . В данную модель нельзя установить больше одной sim-карты.. Смартфон  имеет 4 Гб  встроенной памяти на борту и процессор Qualcomm MSM7227, 1000 МГц', '2020-09-01 15:34:43'),
(66, 15, 'GlobusGPS GL-800Android', 7500, 0, 'GlobusGPS GL-800Android.jpg', 'Перед приобретением GlobusGPS GL-800Android по самой низкой цене, изучите характеристики, видео обзоры, плюсы и минусы модели, отзывы покупателей.', '2020-09-01 15:34:43'),
(67, 5, 'Alcatel One Touch 992D', 7600, 0, 'alcatel_one_touch_992d.jpg', 'Смартфон  Alcatel One Touch 992D с установленной операционной системой Android 4.0  и размером дисплея 4 дюйма. . Смартфон  оснащен аккумулятором типа Li-Ion  позволяющий говорить до 13.5 часов  и находиться в режиме ожидания 400 часов . Стоит отметить, что у Alcatel One Touch 992D есть поддержка двух сим-карт. Для пользователя выделено 4 Гб  памяти и процессор MediaTek MT6577, 1000 МГц .', '2020-09-01 15:34:43'),
(68, 16, 'TeXet TM-5200', 7500, 0, 'TeXet TM-5200.jpg', 'Смартфон  teXet TM-5200 с установленной операционной системой Android 2.3  и диагональю экрана 5.25 дюйма. . Смартфон  оснащен аккумулятором типа Li-Ion . Есть возможность установить 2 sim карты.. Так же, стоит отметить, что в Смартфон  есть 512 Мб  памяти и процессор MediaTek MT6573, 800 МГц', '2020-09-01 15:34:43'),
(69, 16, 'TeXet TM-5204', 7600, 0, 'TeXet TM-5204.jpg', 'Смартфон  teXet TM-5204 с установленной операционной системой Android 4.0  и диагональю экрана 5.25 дюйма. . Есть возможность установить 2 sim карты.. Не лишним будет сказать, что Смартфон  имеет 4 Гб  памяти и процессор MediaTek MT6575, 1000 МГц', '2020-09-01 15:34:43'),
(70, 3, 'ZTE Skate', 7700, 0, 'ZTE Skate.jpg', 'Смартфон  ZTE Skate, оснащенный операционной системой Android 2.3  и диагональю экрана 4.3 дюйма. . Смартфон  имеет аккумулятор Li-Ion  дающий возможность общаться до 5 часов  и быть в режиме ожидания 288 часов . В данную модель нельзя установить больше одной sim-карты.', '2020-09-01 15:34:43'),
(71, 16, 'TeXet TM-4504', 7900, 0, 'TeXet TM-4504.jpg', 'Смартфон  teXet TM-4504 с установленной операционной системой Android 4.0  и размером дисплея 4.5 дюйма. . Смартфон  оснащен аккумулятором типа Li-Ion  дающий возможность общаться до 10 часов  и находиться в режиме ожидания 340 часов . Модель teXet TM-4504 имеет поддержку 2-ух sim-карт. Смартфон  имеет 4 Гб  встроенной памяти на борту и процессор MediaTek MT6575, 1000 МГц', '2020-09-01 15:34:44'),
(72, 17, 'Bliss S5', 8000, 0, 'bliss_s5.jpg', 'Смартфон  Bliss S5 с операционной системой Android 4.0  и размером дисплея 5 дюйма. . Есть возможность установить две сим карты.. Не лишним будет сказать, что Смартфон  имеет 4 Гб  памяти и процессор Qualcomm MSM7227A, 1000 МГц .', '2020-09-01 15:34:44'),
(73, 18, 'Motorola Motoluxe', 8000, 0, 'Motorola Motoluxe.jpg', 'Смартфон  Motorola MOTOLUXE с установленной операционной системой Android 2.3  и диагональю экрана 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion  позволяющий говорить до 6.5 часов  и находиться в режиме ожидания 450 часов . Модель поддерживает только одну сим-карту.. В Смартфон  установленно 1 Гб  памяти и процессор Qualcomm MSM7227A, 800 МГц', '2020-09-01 15:34:44'),
(74, 10, 'Highscreen Alpha GT', 8000, 4000, 'Highscreen Alpha GT.jpg', 'Смартфон  Highscreen Alpha GT, оснащенный операционной системой Android 4.0  и диагональю экрана 4 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion . Есть возможность установить две сим карты.. В Смартфон  установленно 4 Гб  памяти и процессор MediaTek MT6575, 1000 МГц .', '2020-09-01 15:34:44'),
(75, 19, 'Nokia Lumia 510', 8000, 4000, 'Nokia Lumia 510.jpg', 'Смартфон  Nokia Lumia 510 с операционной системой MS Windows Phone 7.5  и размером дисплея 4 дюйма. . Смартфон  оснащен аккумулятором типа Li-Ion  дающий возможность общаться до 6.2 часов  и быть в режиме ожидания 738 часов . В данную модель нельзя установить больше одной sim-карты.. Не лишним будет сказать, что Смартфон  имеет 4 Гб  памяти.', '2020-09-01 15:34:44'),
(76, 5, 'Alcatel OT-995', 6000, 0, 'alcatel_one_touch_995.jpg', 'Смартфон  Alcatel OT-995 с операционной системой Android 4.0  и диагональю экрана 4.3 дюйма. . Смартфон  оснащен аккумулятором типа Li-Ion . Модель поддерживает только одну сим-карту.. Смартфон  имеет 2 Гб  встроенной памяти на борту и процессор Qualcomm MSM 8255T, 1400 МГц .', '2020-09-01 15:34:44'),
(77, 15, 'GlobusGPS GL-800Concorde', 8000, 0, 'GlobusGPS GL-800Concorde.jpg', 'Перед приобретением GlobusGPS GL-800Concorde по самой низкой цене, изучите характеристики, плюсы и минусы модели, отзывы покупателей.', '2020-09-01 15:34:44'),
(79, 13, 'Sony Ericsson Xperia X10', 8000, 4000, 'Sony Ericsson Xperia X10.jpg', 'Смартфон  Sony Ericsson Xperia X10 с установленной операционной системой Android 2.3  и размером дисплея 4 дюйма. . Смартфон  иммет аккумулятор типа Li-polymer  дающий возможность общаться до 6.9 часов  и находиться в режиме ожидания 600 часов . В данную модель нельзя установить больше одной сим-карты.. Модель оснащена 1 Гб  памяти и процессор Qualcomm QSD8250, 1000 МГц', '2020-09-01 15:34:44'),
(80, 2, 'Samsung Omnia M7530', 8300, 4150, 'Samsung Omnia M7530.jpg', 'Нецарапающееся стекло, модуль ГЛОНАСС\r\n\r\n1000 Мгц процессор + графический процессор\r\n\r\nБыстрый интернет HSDPA, Super AMOLED LCD-технология\r\n\r\nСъемка HD видео (720p), поддержка видео-звонков\r\n\r\nПлатформа Windows Phone 7.5, встроенный GPS + A-GPS', '2020-09-01 15:34:44'),
(81, 5, 'Alcatel OneTouch 997D', 8500, 4250, 'alcatel_one_touch_997d.jpg', 'Смартфон  Alcatel OneTouch 997D с операционной системой Android 4.0  и размером дисплея 4.3 дюйма. . Смартфон  имеет аккумулятор Li-Ion  позволяющий общаться до 16 часов  и находиться в режиме ожидания 400 часов . Модель Alcatel OneTouch 997D имеет поддержку 2-ух sim-карт. Модель оснащена 2 Гб  памяти и процессор MediaTek MT6577, 1000 МГц .', '2020-09-01 15:34:44'),
(82, 13, 'Sony Xperia J', 8500, 0, 'Sony Xperia J.jpg', 'Смартфон  Sony Xperia J с операционной системой Android 4.1  и размером дисплея 4 дюйма. . Смартфон  имеет аккумулятор Li-Ion  позволяющий общаться до 7.3 часов  и быть в режиме ожидания 618 часов . В данную модель нельзя установить больше одной сим-карты.. Смартфон  имеет 4 Гб  встроенной памяти на борту и процессор Qualcomm MSM7227A, 1000 МГц', '2020-09-01 15:34:44'),
(83, 9, 'Fly IQ441 Radiance', 8600, 0, 'fly_iq441_radiance.jpg', 'Смартфон  Fly IQ441 Radiance с операционной системой Android 4.0  и размером дисплея 4.3 дюйма. . Смартфон  имеет аккумулятор Li-Ion  позволяющий общаться до 6 часов  и быть в режиме ожидания 400 часов . Есть возможность установить 2 sim карты.. В Смартфон  установленно 4 Гб  памяти и процессор MediaTek MT6577, 1000 МГц .', '2020-09-01 15:34:45'),
(84, 11, 'Philips Xenium W732', 8700, 0, 'Philips Xenium W732.jpg', 'Смартфон  Philips Xenium W732, оснащенный операционной системой Android 4.0  и диагональю экрана 4.3 дюйма. . Смартфон  имеет аккумулятор Li-Ion  дающий возможность общаться до 13 часов  и находиться в режиме ожидания 800 часов . Есть возможность установить две сим карты.. Для пользователя выделено 4 Гб  памяти и процессор MediaTek MT6575, 1000 МГц .', '2020-09-01 15:34:45'),
(85, 1, 'Huawei Honor U8860', 8700, 0, 'Huawei Honor U8860.jpg', NULL, '2020-09-01 15:34:45'),
(87, 21, 'Мегафон SP-A10', 8800, 0, 'Мегафон SP-A10.jpg', 'Смартфон  МегаФон SP-A10 с операционной системой Android 2.3  и диагональю экрана 4.3 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion . В данную модель нельзя установить больше одной сим-карты.. Не лишним будет сказать, что Смартфон  имеет 2 Гб  памяти и процессор Qualcomm MSM 8255, 1400 МГц', '2020-09-01 15:34:45'),
(88, 4, 'Explay Infinity', 8900, 0, 'explay_infinity.jpg', 'Смартфон  Explay Infinity, оснащенный операционной системой Android 4.0  и диагональю экрана 4.3 дюйма. . Смартфон  имеет аккумулятор Li-Ion  позволяющий общаться до 5.6 часов  и находиться в режиме ожидания 170 часов . Есть возможность установить две сим карты.. Так же, стоит отметить, что в Смартфон  есть 4 Гб  памяти и процессор MediaTek MT6575, 1000 МГц .', '2020-09-01 15:34:45'),
(89, 12, 'LG Optimus L7', 8900, 0, 'LG Optimus L7.jpg', 'Смартфон  LG Optimus L7 P705, оснащенный операционной системой Android 4.1  и размером дисплея 4.3 дюйма. . Смартфон  иммет аккумулятор типа Li-Ion  дающий возможность общаться до 10.5 часов  и быть в режиме ожидания 700 часов . Модель поддерживает только одну сим-карту.. Так же, стоит отметить, что в Смартфон  есть 4 Гб  памяти и процессор Qualcomm MSM7227A, 1000 МГц', '2020-09-01 15:34:45'),
(90, 21, 'Мегафон SP-W1', 8900, 0, 'Мегафон SP-W1.jpg', 'Смартфон  МегаФон SP-W1, оснащенный операционной системой MS Windows Phone 7.5  и диагональю экрана 4.3 дюйма. . Смартфон  имеет аккумулятор Li-Ion . Модель поддерживает только одну сим-карту.. Так же, стоит отметить, что в Смартфон  есть 4 Гб  памяти и процессор Qualcomm MSM 8255, 1000 МГц', '2020-09-01 15:34:45'),
(94, 2, 'Samsung S4-mini', 6300, 0, 'Samsung S4-mini.jpg', 'Смартфон  Samsung Galaxy S4 mini GT-I9195 с операционной системой Android 4.2  и диагональю экрана 4.27 дюйма. . Смартфон  имеет аккумулятор Li-Ion  позволяющий общаться до 12 часов  и находиться в режиме ожидания 300 часов . В данную модель нельзя установить больше одной сим-карты.. Смартфон  имеет 8 Гб  встроенной памяти на борту и процессор 1700 МГц', '0000-00-00 00:00:00'),
(100, 2, 'Samsung S10 maxi', 25000, NULL, NULL, NULL, '2020-09-28 05:27:03');

-- --------------------------------------------------------

--
-- Структура таблицы `goods_discounts`
--

CREATE TABLE `goods_discounts` (
  `id_good_discount` int(11) NOT NULL,
  `id_good` int(11) NOT NULL,
  `id_discount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods_discounts`
--

INSERT INTO `goods_discounts` (`id_good_discount`, `id_good`, `id_discount`) VALUES
(354, 34, 42),
(355, 35, 42),
(359, 42, 43),
(366, 25, 43),
(367, 43, 44),
(368, 45, 44),
(369, 46, 44),
(370, 74, 46),
(371, 75, 46),
(372, 79, 46),
(373, 80, 46),
(374, 81, 46),
(375, 48, 42),
(377, 49, 43);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id_order` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `first_name` varchar(128) DEFAULT NULL,
  `phone` varchar(128) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `mailing` varchar(16) DEFAULT 'off',
  `discount_card` varchar(128) DEFAULT NULL,
  `price_order` int(11) DEFAULT NULL,
  `addresses` varchar(512) DEFAULT NULL,
  `delivery_method` varchar(63) NOT NULL,
  `comments` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `status` varchar(128) NOT NULL DEFAULT 'В процессе'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id_order`, `id_user`, `first_name`, `phone`, `email`, `mailing`, `discount_card`, `price_order`, `addresses`, `delivery_method`, `comments`, `created_at`, `status`) VALUES
(167, 153, '', '900090909', '', 'off', '', 14000, 'Москва', 'самовывоз', '', '2020-09-28 05:03:38', 'Доставка'),
(168, 153, 'Иван', '900090909', 'akor@gmail.com', 'on', '73001684', 4350, 'Москва', 'доставка', 'ASAP', '2020-09-28 05:04:37', 'Обработан'),
(170, 154, '', '900090909', '', 'off', '', 16200, 'Москва', 'самовывоз', '', '2020-09-28 05:22:09', 'Отменен'),
(171, 154, 'Иван', '900090909', 'akor@gmail.com', 'on', '73001684', 13500, 'Москва', 'доставка', 'asap', '2020-09-28 05:23:15', 'Обработан'),
(172, 160, '', '900090909', '', 'off', '', 19800, 'Москва', 'самовывоз', '', '2020-09-28 06:24:43', 'В процессе');

-- --------------------------------------------------------

--
-- Структура таблицы `params`
--

CREATE TABLE `params` (
  `id_good` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `standart` varchar(511) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `proc` varchar(255) DEFAULT NULL,
  `sim` int(11) DEFAULT NULL,
  `display` float DEFAULT NULL,
  `camera` float DEFAULT NULL,
  `ram` int(11) DEFAULT NULL,
  `rom` int(11) DEFAULT NULL,
  `battery` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `params`
--

INSERT INTO `params` (`id_good`, `year`, `standart`, `os`, `proc`, `sim`, `display`, `camera`, `ram`, `rom`, `battery`) VALUES
(43, 2012, 'GSM/HSPA', 'Android 2.3 (Gingerbread)', '800 MHz Cortex-A9', 2, 4, 3.15, 1000, 150, 1500),
(49, 2012, 'GSM/HSPA', 'Android 2.3 (Gingerbread)', '800 MHz Cortex-A9', 2, 4, 5, 1000, 150, 1500),
(59, 2012, 'EDGE/HSPA', 'Windows Phone 7.5', 'Qualcomm MSM7227a', 1, 4.08, 5, 512, 4000, 1500),
(60, 2012, 'EDGE/HSPA', 'Android 4.0', 'Qualcomm MSM7227a', 2, 4, 5, 512, 4000, 1500),
(67, 2012, 'EDGE/HSPA', 'Android 4.0', 'Qualcomm MSM7227a', 2, 4, 5, 512, 4000, 1500),
(81, 2012, 'EDGE/HSPA', 'Android 4.0', 'Qualcomm MSM7227a', 2, 4.3, 8, 1000, 4000, 1800),
(72, 2012, 'EDGE/HSPA/LTE', 'Android 7.0', 'Qualcomm MSM7227a', 2, 5.5, 5, 1000, 8000, 2800),
(48, 2012, 'EDGE/HSPA+', 'Android 4.0', 'MediaTek MT6575', 2, 4, 5, 512, 4000, 1500),
(76, 2012, 'EDGE/HSPA', 'Android 2.3 (Gingerbread)', 'QUALCOMM MSM 8255T', 1, 4.3, 5, 512, 800, 1500),
(42, 2012, 'EDGE/HSPA', 'Android 4.0', 'ARM Cortex-A9', 2, 4, 5, 512, 4000, 2200),
(88, 2013, 'EDGE/HSPA+', 'Android 4.0', 'MediaTek MT6575', 2, 4.3, 8, 512, 4000, 1600),
(45, 2012, 'EDGE/HSPA', 'Android 4.0', 'MediaTek MT6577', 2, 4, 5, 512, 4000, 1600),
(56, 2012, 'EDGE/HSPA', 'Android 2.3 (Gingerbread)', 'Qualcomm MSM 8255T', 1, 4, 5, 512, 1000, 1350),
(61, 2012, 'EDGE/HSPA', 'Android 4.0', 'MediaTek MT6577', 2, 4, 5, 512, 4000, 2500),
(83, 2012, 'EDGE/HSPA', 'Android 4.0', 'MediaTek MT6577', 2, 4.3, 5, 512, 4000, 1800),
(66, 2013, 'HSPA+', 'Android 2.3 (Gingerbread)', 'Qualcomm MSM7227a', 2, 4.3, 5, 512, 8000, 1500),
(77, 2013, 'HSPA+', 'Android 2.3 (Gingerbread)', 'Qualcomm MSM7227a', 2, 4.3, 3.2, 512, 8000, 1500),
(46, 2013, 'EDGE/HSPA', 'Android 2.3 (Gingerbread)', 'MediaTek MT6573', 2, 4.3, 5, 512, 512, 1500),
(74, 2012, 'EDGE/HSPA+', 'Android 4.0', 'MediaTek MT6575', 2, 4, 8, 1000, 4000, 1900),
(25, 2012, 'EDGE/HSPA+', 'Android 4.0', 'MediaTek MT6577', 2, 4.3, 5, 1000, 4000, 1930),
(34, 2012, 'EDGE/HSPA+', 'Android 4.0', 'MediaTek MT6577', 1, 4.5, 8, 2000, 8000, 2230),
(51, 2012, 'EDGE/HSPA', 'Android 2.3 (Gingerbread)', 'Qualcomm MSM7227A', 1, 4, 5, 512, 2400, 1500),
(64, 2012, 'EDGE/HSPA+', 'Android 2.3 (Gingerbread)', 'MediaTek MT6575', 2, 4, 5, 512, 2400, 1500),
(85, 2011, 'EDGE/HSPA+', 'Android 2.3 (Gingerbread)', 'MediaTek MT6575', 1, 4, 8, 512, 4000, 1930),
(57, 2012, 'EDGE/HSPA', 'Android 4.0', 'Qualcomm MSM7225A', 1, 4, 5, 512, 2500, 1540),
(58, 2011, 'EDGE/HSPA', 'Android 2.2', 'TI OMAP3630', 1, 4, 5, 512, 2000, 1500),
(62, 2012, 'EDGE/HSPA', 'Android 4.0', 'Qualcomm MSM7225A', 2, 4, 5, 512, 2500, 1540),
(89, 2012, 'EDGE/HSPA+', 'Android 4.0', 'Qualcomm MSM7227A', 1, 4.3, 5, 512, 4000, 1700),
(73, 2012, 'EDGE/HSPA+', 'Android 2.3 (Gingerbread)', 'Qualcomm MSM7227A', 1, 4, 8, 512, 1000, 1400),
(65, 2013, 'EDGE/HSPA+', 'Android 2.3 (Gingerbread)', 'Qualcomm MSM7227A', 1, 3.7, 5, 768, 4000, 1230),
(75, 2012, 'EDGE/HSPA+', 'Windows Phone 7.5', 'Qualcomm Snapdragon S1', 1, 4, 5, 256, 4000, 1300),
(55, 2012, 'EDGE/HSPA+', 'Android 4.0', 'MediaTek MT6575', 2, 4, 5, 512, 2000, 1630),
(84, 2012, 'EDGE/HSPA+', 'Android 4.0', 'MediaTek MT6575', 2, 4.3, 5, 512, 2000, 2400),
(52, 2012, 'EDGE/HSPA+', 'Android 4.0', 'ARM Cortex-A9', 2, 4.3, 5, 512, 4000, 1500),
(35, 2014, 'EDGE', 'Android 2.3 (Gingerbread)', 'MediaTek MT6575', 1, 3, 3.2, 50, 8000, 1000),
(80, 2014, 'EDGE/HSPA', 'Windows Phone 7.5', 'MediaTek MT6575', 1, 4, 5, 384, 4000, 1500),
(94, 2014, 'EDGE/HSPA+', 'Android 4.2', 'Qualcomm MSM7227A', 2, 4.3, 8, 1500, 8000, 1700),
(79, 2009, 'EDGE/HSPA+', 'Android 1.6', 'Qualcomm QSD8250', 1, 4, 8.1, 384, 1000, 1500),
(82, 2012, 'EDGE/HSPA+', 'Android 4.0', 'Qualcomm MSM7227A', 1, 4, 5, 512, 4000, 1750),
(68, 2012, 'EDGE/HSPA', 'Android 2.3 (Gingerbread)', 'MediaTek MT6573', 2, 5.25, 5, 512, 512, 2500),
(69, 2012, 'EDGE/HSPA', 'Android 4.0', 'MediaTek MT6575', 2, 5.25, 5, 512, 4000, 2500),
(71, 2012, 'EDGE/HSPA', 'Android 4.0', 'MediaTek MT6575', 2, 4.5, 5, 512, 4000, 1700),
(36, 2015, 'EDGE/HSPA+', 'Android 4.0', 'NVIDIA Tegra 3', 2, 4.5, 8, 1000, 16000, 1800),
(50, 2012, 'EDGE/HSPA', 'Android 2.3 (Gingerbread)', 'Qualcomm MSM7227A', 2, 4, 5, 512, 4000, 1650),
(53, 2012, 'EDGE/HSPA', 'Android 4.0', 'NVIDIA Tegra 2', 1, 4.3, 5, 1000, 4000, 1650),
(54, 2012, 'EDGE/HSPA+', 'Android 4.0', 'MediaTek MT6577', 2, 4, 5, 512, 4000, 1600),
(70, 2011, 'EDGE/HSPA', 'Android 2.3 (Gingerbread)', 'MediaTek MT6575', 1, 4.3, 5, 512, 512, 1400),
(87, 2015, 'EDGE/HSPA+/LTE', 'Android 2.3 (Gingerbread)', 'QUALCOMM MSM 8255T', 2, 6.5, 12, 512, 4000, 3500),
(90, 2015, 'EDGE/HSPA+/LTE', 'IOS 9', 'QUALCOMM MSM 8255T', 1, 4, 12, 2000, 16000, 1642),
(100, 2020, '5G', '', '', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `id_role` smallint(6) NOT NULL,
  `name_role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id_role`, `name_role`) VALUES
(1, 'user'),
(2, 'moderator'),
(3, 'stockman'),
(5, 'manager'),
(7, 'admin');

-- --------------------------------------------------------

--
-- Дублирующая структура для представления `summ_calc`
-- (См. Ниже фактическое представление)
--
CREATE TABLE `summ_calc` (
`id_good` int(11)
,`id_order` int(11)
,`sum` bigint(21)
,`new_sum` bigint(21)
);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` smallint(6) NOT NULL,
  `login` varchar(128) DEFAULT NULL,
  `pass` varchar(256) DEFAULT NULL,
  `first_name` varchar(128) DEFAULT NULL,
  `last_name` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `male` varchar(16) DEFAULT NULL,
  `birthday` varchar(64) DEFAULT NULL,
  `id_role` smallint(6) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `login`, `pass`, `first_name`, `last_name`, `email`, `male`, `birthday`, `id_role`) VALUES
(153, NULL, NULL, 'temp_shmemp_user_puser', NULL, NULL, NULL, NULL, 1),
(154, 'user', '$2y$10$IJXhsMtPQuOyrUGteiTb2OBrOiOdIChiJ.aUpnSRh43gHXzyu2LnO', 'Иван', 'Иванов', 'akor@gmail.com', 'man', '1988-07-14', 1),
(157, 'moderator', '$2y$10$tf6D.3qbW17WbBuslD6on.09to61tS3FBzsR4.0OdKL9T5HDLJR/e', NULL, NULL, NULL, NULL, NULL, 2),
(158, 'stockman', '$2y$10$VD5R9S/gJkTjb/ETvM88AetLJQbcIPsEQhwztGMzVuuQXgnIoaNxy', NULL, NULL, NULL, NULL, NULL, 3),
(159, 'manager', '$2y$10$c.m9719OlHPNKr0UVWStge37LaTkDzNu0C4upmXF/hohHKxpwPJGm', NULL, NULL, NULL, NULL, NULL, 5),
(160, 'admin', '$2y$10$37I9L1p4SGAIQv4q25NLz..mg.xvLF9AjR93cSU/W8rlXLT/WoT3C', NULL, NULL, NULL, NULL, NULL, 7);

-- --------------------------------------------------------

--
-- Структура для представления `summ_calc`
--
DROP TABLE IF EXISTS `summ_calc`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `summ_calc`  AS  select `basket`.`id_good` AS `id_good`,`basket`.`id_order` AS `id_order`,`basket`.`amount` * `goods`.`price_good` AS `sum`,`basket`.`amount` * `goods`.`new_price` AS `new_sum` from (`basket` join `goods`) where `basket`.`id_good` = `goods`.`id_good` and `basket`.`id_order` = '172' ;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`id_basket`);

--
-- Индексы таблицы `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id_brand`),
  ADD UNIQUE KEY `name_brand` (`name_brand`);

--
-- Индексы таблицы `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`id_discount`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id_good`),
  ADD UNIQUE KEY `name` (`name_good`),
  ADD KEY `goods_id_brand_foreign` (`id_brand`) USING HASH;

--
-- Индексы таблицы `goods_discounts`
--
ALTER TABLE `goods_discounts`
  ADD PRIMARY KEY (`id_good_discount`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_order`);

--
-- Индексы таблицы `params`
--
ALTER TABLE `params`
  ADD KEY `params_id_good_foreign_key` (`id_good`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_role`),
  ADD UNIQUE KEY `id_role` (`id_role`),
  ADD UNIQUE KEY `name_role` (`name_role`) USING HASH;

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `users_id_role_foreign` (`id_role`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `basket`
--
ALTER TABLE `basket`
  MODIFY `id_basket` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=346;

--
-- AUTO_INCREMENT для таблицы `brands`
--
ALTER TABLE `brands`
  MODIFY `id_brand` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT для таблицы `discounts`
--
ALTER TABLE `discounts`
  MODIFY `id_discount` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id_good` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT для таблицы `goods_discounts`
--
ALTER TABLE `goods_discounts`
  MODIFY `id_good_discount` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=378;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=173;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `goods`
--
ALTER TABLE `goods`
  ADD CONSTRAINT `goods_id_brand_foreign` FOREIGN KEY (`id_brand`) REFERENCES `brands` (`id_brand`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `params`
--
ALTER TABLE `params`
  ADD CONSTRAINT `params_id_good_foreign_key` FOREIGN KEY (`id_good`) REFERENCES `goods` (`id_good`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_id_role_foreign` FOREIGN KEY (`id_role`) REFERENCES `roles` (`id_role`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
